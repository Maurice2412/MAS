<?php  
//export.php  
include('../connect.php');
$output = "";
  $output .= '<table>';
  $output .= "<tr><td colspan='5'><br></td></tr>";
  $output .= "<tr><td colspan='5'><br>Musanze Art Studio Hub Adventure</td></tr>";
  $output .= "<tr><td colspan='5'><br>Musanze - Rwanda</td></tr>";
  $output .= "<tr><td colspan='5'><br></td></tr>";
  $output .= "<tr><td colspan='5'><br></td></tr>";
  $output .= "<tr><td colspan='5'><br></td></tr>";

  $output .= "<tr><td colspan='5' style='padding: 10px 20px;background: #09F; color:#fff; font-weight: bold;'>Sales Report</td></tr>
    <tr>
      <td class='tdheader' style='border: 1px solid #000; padding: 5px 10px; background: #444; color: white;'>Transaction Date</td>
      <td class='tdheader' style='border: 1px solid #000; padding: 5px 10px; background: #444; color: white;'>Product Name</td>
      <td class='tdheader' style='border: 1px solid #000; padding: 5px 10px; background: #444; color: white;'>Category / Description</td>
      <td class='tdheader' style='border: 1px solid #000; padding: 5px 10px; background: #444; color: white;'>Price</td>
      <td class='tdheader' style='border: 1px solid #000; padding: 5px 10px; background: #444; color: white;'>Qty</td>
       <td class='tdheader' style='border: 1px solid #000; padding: 5px 10px; background: #444; color: white;'>Amount</td>
      <td class='tdheader' style='border: 1px solid #000; padding: 5px 10px; background: #444; color: white;'>Profit</td>
    </tr>";
    $total = 0;

                            $result = $db->prepare("SELECT * FROM sales ORDER BY transaction_id DESC");
                            $result->execute();
                            for($i=0; $row = $result->fetch(); $i++)
  {
      $output .= "<tr>
      <td style='border: 1px solid #000; padding: 5px 10px;'>".$row['transaction_id']."</td>
      <td style='border: 1px solid #000; padding: 5px 10px;'>".$row['date']."</td>
      <td style='border: 1px solid #000; padding: 5px 10px;'>".$row_t['name']."</td>
      <td style='border: 1px solid #000; padding: 5px 10px;'>".$row['invoice_number']." Rwf</td>
      <td style='border: 1px solid #000; padding: 5px 10px;'>".$row['amount']."</td>
      </tr>";
      $total += $row['profit'];
    }
    $output .= "<tr>
      <td style='font-size: 20px; border: 1px solid $000;pa background: #fff;text-align: right;' colspan='3'>Total Amount: </td><td style='font-size: 20px; border: 1px solid $000;pa background: #fff;text-align: right;' colspan='2'> <b>$total Rwf</b></td>
    </tr>";
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=Payments_report.xls');
  echo $output;

?>

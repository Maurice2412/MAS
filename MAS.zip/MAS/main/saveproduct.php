<?php
session_start();
include('../connect.php');
$b = $_POST['name'];
$d = $_POST['price'];
$f = $_POST['qty'];
$g = $_POST['o_price'];
$h = $_POST['profit'];
$i = $_POST['gen'];
$j = $_POST['date_arrival'];
$k = $_POST['qty_sold'];
// query
$sql = "INSERT INTO products (product_name,price,qty,o_price,profit,gen_name,date_arrival,qty_sold) VALUES (:b,:d,:f,:g,:h,:i,:j,:k)";
$q = $db->prepare($sql);
$q->execute(array(':b'=>$b,':d'=>$d,':f'=>$f,':g'=>$g,':h'=>$h,':i'=>$i,':j'=>$j,':k'=>$k));
header("location: products.php");


?>